# Predictive Analytics Using Historical Data

## 1. Project overview
This project demonstrates how historical monthly sales data can be cleaned, explored and used to forecast future trends. It compares **Linear Regression** and **Random Forest Regression** and generates a 12-month forecast.

**Important:** `historical_sales.csv` is a clearly labelled, synthetic teaching dataset generated for this assignment. It is not real company or customer data.

## 2. Objectives
- Inspect and preprocess historical data.
- Identify and handle missing numeric values using column means.
- Explore historical sales trends through visualizations.
- Build and compare regression models.
- Evaluate predictions using MAE, RMSE and R².
- Forecast sales for the next 12 months.

## 3. Project structure
```text
predictive_analytics_historical_data/
├── historical_sales.csv
├── main.py
├── requirements.txt
├── README.md
└── outputs/                 # created automatically after running
    ├── historical_sales.png
    ├── actual_vs_predicted.png
    ├── 12_month_forecast.png
    ├── model_metrics.csv
    └── next_12_month_forecast.csv
```

## 4. Requirements
- Python 3.9 or later
- pandas
- numpy
- matplotlib
- scikit-learn

## 5. Run the project

### Windows (VS Code / Command Prompt)
1. Download and extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open the terminal in that folder.
4. (Recommended) Create a virtual environment:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```
5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Run:
   ```bash
   python main.py
   ```
7. Open the `outputs` folder to view charts and CSV results.

### Google Colab
Upload `historical_sales.csv` and `main.py` to the Colab session, then run:
```python
!pip install -r requirements.txt
!python main.py
```
If you do not upload `requirements.txt`, install with:
```python
!pip install pandas numpy matplotlib scikit-learn
```

## 6. Methodology
1. Load the CSV and sort records by date.
2. Check missing values and replace missing numeric values with each column's mean.
3. Create calendar and historical lag features (previous month, 3 months, 6 months and 3-month rolling average).
4. Split chronologically: first 80% for training and final 20% for testing. This avoids randomly mixing future observations into training.
5. Train Linear Regression and Random Forest models.
6. Compare models using:
   - **MAE:** average absolute prediction error; lower is better.
   - **RMSE:** penalizes larger errors more strongly; lower is better.
   - **R²:** proportion of target variation explained by the model; closer to 1 is generally better.
7. Select the model with the lowest test RMSE and forecast the next 12 months.

## 7. Expected output
The program prints missing-value information, model metrics, the selected model and the 12-month forecast. It creates three PNG charts and two result CSV files in `outputs/`.

Exact metric values are produced when the program runs. Results are not hard-coded.

## 8. Limitations
- The included data is synthetic and intended for learning, not business decisions.
- Future advertising spend and product price are held at their latest observed values; promotions are set to zero.
- Forecast quality depends on the patterns represented in the historical data. Real deployment requires a genuine, relevant dataset and validation.

## 9. Conclusion
The project demonstrates an end-to-end predictive analytics workflow, from data cleaning and visualization to regression modelling, evaluation and forecasting. Comparing two models helps identify which performs better on the held-out historical period. The generated forecast illustrates how historical patterns can support planning, while the limitations show why real-world forecasts must be validated with suitable data.

## 10. GitHub upload
Create a new repository on GitHub (for example, `predictive-analytics-historical-data`). In the project folder, run:
```bash
git init
git add .
git commit -m "Add predictive analytics assignment"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/predictive-analytics-historical-data.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Do not upload passwords, access tokens or private data.
